package com.example.mycoffe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    RatingBar ratingBar;
    ImageView imageView;
    TextView txtJudul, txtJenis, txtPerbandingan, txtRating, txtDetail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ratingBar = findViewById(R.id.ratingbar);
        imageView = findViewById(R.id.imgDetail);
        txtJudul = findViewById(R.id.titleDetail);
        txtJenis = findViewById(R.id.jenisDetail);
        txtPerbandingan = findViewById(R.id.perbandinganDetail);
        txtRating = findViewById(R.id.ratingDetail);
        txtDetail = findViewById(R.id.deskripsiDetail);

        Intent intent = getIntent();
        imageView.setImageResource(intent.getIntExtra("eImage",0));
        txtJudul.setText(intent.getStringExtra("eJudul"));
        txtJenis.setText(intent.getStringExtra("eJenis"));
        txtPerbandingan.setText(intent.getStringExtra("ePerbandingan"));
        txtRating.setText(intent.getStringExtra("eRating"));
        txtDetail.setText(intent.getStringExtra("eDetail"));

        float rate = Float.parseFloat(intent.getStringExtra("eRating"));
        rate = rate/2;
        ratingBar.setRating(rate);
    }
}
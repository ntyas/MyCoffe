package com.example.mycoffe;

import java.util.ArrayList;

public class CoffeData {
    private static String[] coffeName = {
            "AFFOGATO",
            "AMERICANO",
            "CAPPUCCINO",
            "COLD BREW",
            "CORDATO",
            "ESPRESSO",
            "FLAT WHITE",
            "FRAPPE",
            "LATTE",
            "MACCHIATO",
            "MOCHACHINO",
            "RED EYE",
            "RISTRETTO",
            "YUANYANG"
    };

    private static String[] coffeJenis = {
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe",
            "Coffe"
    };

    private static int[] coffeCover = {
            R.drawable.affogato,
            R.drawable.americano,
            R.drawable.cappuccino,
            R.drawable.coldbrew,
            R.drawable.cordato,
            R.drawable.espresso,
            R.drawable.flatwhite,
            R.drawable.frappe,
            R.drawable.latte,
            R.drawable.macchiato,
            R.drawable.mochachino,
            R.drawable.redeye,
            R.drawable.ristretto,
            R.drawable.yuanyang
    };

    private static  String[] coffeDetail = {
            "Affogato merupakan jenis minuman kopi yang mencampurkan espresso yang kuat dan pahit dengan es krim vanilla yang nikmat. Jenis minuman kopi ini tercipta dari 2/5 esspresso yang dipadukan dengan 3/5 es krim. Jenis kopi ini menghadirkan sebuah kenikmatan paling pas dari perkawinan rasa manis es krim dan pahit sempurnanya espresso.",
            "Pada dasarnya americano sama dengan espresso, tetapi menggunakan lebih banyak air. Jadi rasa kopinya tidak terlalu kental dan tidak terlalu kuat. Americano terdiri dari satu shot espresso yang dituangkan dalam cangkir berukuran 178 mililiter yang dicampur dengan air panas hingga memenuhi gelas. Jenis minuman kopi ini nikmat disantap dalam keadaan panas maupun dingin.",
            "Jenis minuman kopi satu ini termasuk yang paling populer di kedai kopi. Cappuccino adalah olahan espresso yang paling banyak digemari, terutama bagi penikmat kopi dengan rasa lebih mild. Minuman ini terdiri dari espresso dan steamed milk dengan rasio 1:1. Namun, ada juga yang memakai perbandingan 1/3 espresso, 1/3 steamed milk, dan 1/3 susu foam. Jenis kopi satu biasanya disajikan dalam cangkir berkapasitas 88 mililiter hingga 177 mililiter. Ciri khas dari jenis kopi ini adalah adanya foam dengan tebal sekitar 2 cm pada bagian permukaannya, serta terdapat taburan coklatnya.",
            "Jenis minuman kopi ini didaptkan dari mencampur hasil gilingan kopi dengan air dingin di satu wadah. Lalu, dibiarkan selama 12 jam atau sampai satu hari penuh, kemudian disaring. Rasa yang dihasilkan cold brew cenderung tidak terlalu pahit dan tidak terlalu asam.",
            "Jenis minuman kopi yang satu ini berasal dari Spanyol dan dari asal kata “cortado” berarti “memotong”. Cortado terdiri dari espresso dan susu hangat. Perbandingan rasio susu pada jenis kopi ini adalah 1:1 atau di beberapa tempat bisa menjadi 1:2. Di Italia (atau di negara lain) cortado sering disebut-sebut mirip dengan macchiato. Hal ini karena komposisi jenis kopi ini mirip.",
            "Jenis kopi ini merupakan kopi murni tanpa menggunakan campuran bahan apapun seperti susu atau gula. Espresso merupakan salah satu jenis minuman kopi yang mulai dikenal di Italia. Espresso dibuat dengan mesin brewing khusus. Cara membuatnya adalah biji kopi diletakkan di dalam mesin brewing, lalu air dialirkan dengan tekanan tinggi. Proses ini menghasilkan ekstrak kopi. Jenis minuman kopi paling dasar ini biasanya disajikan dalam cangkir khusus espresso berukuran 30 mililiter sampai 118 mililiter. Espresso bertekstur pekat dan pahit, dengan buih putih di atasnya yang terbentuk dari tekanan minyak dalam biji kopi.",
            "Meski menggunakan bahan baku yang sama yakni kopi dan susu, jenis kopi ini sebenarnya berbeda dengan café latte dan cappuccino lho. Flat white awalnya diperkenalkan di Australia dan Selandia Baru pada tahun 1980 dan perlahan-lahan berkembang sampai ke Amerika Serikat. Flat white menggunakan rasio susu lebih banyak dari café latte dan disajikan hampir tanpa foam. Jenis minuman kopi ini biasanya terdiri dari 60 mililiter textured milk alias microfoam atau gelembung yang terbentuk saat susu dipanaskan. Kemudian dua shot espresso dituang di atasnya dan dicampur menjadi satu. Bagian atasnya terdapat krema kopi dan setitik foam. Dari segi rasa Flat white lebih kuat dari café latte dan lebih lembut dari cappuccino.",
            "Jenis kopi ini biasanya disajikan dalam keadaan dingin. Frappe adalah minuman es kopi berlapis busa yang berasal dari negara Yunani. Frappe terbuat dari kopi instan, air, gula dan es batu. Jenis minuman kopi ini pertama kali diciptakan oleh Dimitrios Vakondios pada September 1957.",
            "Jenis minuman kopi satu ini bisa dibilang minuman paling aman buat yang nggak terlalu suka kopi. Latte ini merupakan kopi yang dicampur dengan susu. Nama aslinya berasal dari bahasa Italia, yaitu caffe latte yang artinya adalah kopi susu. Bukan itu aja, komposisi latte ini lebih banyak susunya dibandingkan dengan kopinya. Latte biasanya menggunakan perbandingan espresso dan susu 2:1. Oleh sebab itu, rasa kopinya tidak begitu kuat. Selain menyuguhkan cita rasa yang nikmat, latte biasanya disajikan dalam cangkir dengan motif indah di atasnya atau yang banyak disebut latte art.",
            "Komposisi jenis minuman kopi satu ini adalah double shot espresso dan susu. Rasio steamed milk dalam minuman ini lebih besar dari espresso, sehingga ada sentuhan milky dan gurih. Perbandingan komposisi pada jenis kopi ini adalah 4:1. Ada dua macam jenis macchiato yaitu espresso macchiato dan latte macchiato.",
            "Mochacino berasal dari campuran espresso dengan coklat dan susu. Jenis minuman kopi ini menargetkan para pecinta kopi yang juga menyukai coklat. Pasalnya, jenis kopi ini merupkan kombinasi espresso dengan susu dan cokelat. Mochachino terbuat dari 1/5 susu, 2/5 cokelat, dan 2/5 espresso.",
            "Jenis minuman kopi yang satu ini terdiri dari espresso dicampur dengan kopi hitam. Jenis kopi ini biasanya lebih popular dengan sebutan coffee with espresso. Di beberapa negara jenis kopi ini memiliki banyak nama antara lain black eye, a shot in the dark dan eye opener.",
            "Berbeda dengan Americano, jenis minuman kopi ini menggunakan air yang lebih sedikit. Nama ristretto berasal dari Bahasa Italia yang berarti “terbatas”. Ristretto sering juga disebut sebagai half espresso karena air yang digunakan dibatasi dan volume kopi yang dihasilkan ristretto hanya setengah dari espresso. Ristretto lebih pekat, singkat dan manis. Meski begitu waktu press dalam pembuatan ristretto sama dengan espresso.",
            "Yuanyang adalah jenis minuman kopi yang terbuat dari kombinasi antara kopi hitam, teh hitam, dan susu kental manis. Takaran kombinasi kopi dan teh pada jenis kopi ini biasanya sama banyaknya. Yuanyang banyak ditemukan di Hongkong dan China. Sebenarnya Kopi Teh ini sudah banyak tersebar di negara-negara lain seperti di Malaysia dengan nama Kopi Cham, Ethiopia dengan nama Spreeze, dan di eropa dengan sebutan coftea yang merupakan singkatan dari coffee dan tea."
    };

    private static  String[] coffePerbandingan = {
            "3:5",
            "?:?",
            "3:1",
            "?:?",
            "1:2",
            "1:-",
            "?:?",
            "1:-",
            "4:1",
            "1:5",
            "?:?",
            "?:?",
            "?:?",
            "?:?"
    };

    private static  String[] coffeRating = {
            "9",
            "8.1",
            "9.1",
            "8.3",
            "7",
            "8",
            "8",
            "8.1",
            "8.9",
            "8.5",
            "7",
            "8",
            "8",
            "8.1"

    };



    static ArrayList<Coffe> getData() {
        ArrayList<Coffe> list = new ArrayList<>();
        for (int i = 0; i < coffeName.length; i++) {
            Coffe manga = new Coffe();
            manga.setTitle(coffeName[i]);
            manga.setJenis(coffeJenis[i]);
            manga.setImg(coffeCover[i]);
            manga.setDetail(coffeDetail[i]);
            manga.setPerbandingan(coffePerbandingan[i]);
            manga.setRating(coffeRating[i]);
            list.add(manga);
        }
        return list;
    }
}

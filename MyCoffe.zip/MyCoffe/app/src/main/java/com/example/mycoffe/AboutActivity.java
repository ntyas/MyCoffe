package com.example.mycoffe;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import de.hdodenhof.circleimageview.CircleImageView;

public class AboutActivity extends AppCompatActivity {
    CircleImageView circleImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        circleImageView = findViewById(R.id.aaaa);
        circleImageView.setImageResource(R.drawable.profil);
    }
}

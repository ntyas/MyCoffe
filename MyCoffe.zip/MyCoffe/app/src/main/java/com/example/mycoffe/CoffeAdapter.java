package com.example.mycoffe;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CoffeAdapter extends RecyclerView.Adapter<CoffeAdapter.CoffeViewHolder> {
    private ArrayList<Coffe> listCoffe;
    public CoffeAdapter(ArrayList<Coffe> listCoffe) {
        this.listCoffe = listCoffe;
    }
    @NonNull
    @Override
    public CoffeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_item, viewGroup, false);
        return new CoffeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CoffeViewHolder coffeViewHolder, int i) {
        final Coffe coffe = listCoffe.get(i);
        coffeViewHolder.img.setImageResource(coffe.getImg());
        coffeViewHolder.txtJudul.setText(coffe.getTitle());
        coffeViewHolder.txtJenis.setText(coffe.getJenis());
        coffeViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), DetailActivity.class);
                intent.putExtra("eImage", coffe.getImg());
                intent.putExtra("eJudul", coffe.getTitle());
                intent.putExtra("eJenis", coffe.getJenis());
                intent.putExtra("eRating", coffe.getRating());
                intent.putExtra("ePerbandingan", coffe.getPerbandingan());
                intent.putExtra("eDetail", coffe.getDetail());
                view.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listCoffe.size();
    }

    public class CoffeViewHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView txtJudul, txtJenis;
        CardView cardView;
        public CoffeViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card);
            img = itemView.findViewById(R.id.imgRow);
            txtJudul = itemView.findViewById(R.id.judulRow);
            txtJenis = itemView.findViewById(R.id.jenisRow);
        }
    }
}